#include <vector>
#include <deque>
//#include <cstddef>


// TreeNode class should go in the "ufl_cap4053::fundamentals" namespace!
namespace ufl_cap4053 { namespace fundamentals {
	template<class T>
	class TreeNode {
	private:
		T& element_;
		
	public:
		std::vector<TreeNode<T>*> *children_;

		TreeNode<T>() : element_(T()) {
			children_ = new std::vector<TreeNode<T>*>();
		}
		TreeNode<T>(T element) : element_(element) {
			children_ = new std::vector<TreeNode<T>*>();
		}
		T& getData() const {
			return element_;
		}
		std::size_t getChildCount() const {
			return children_->size();
		}
		TreeNode<T>* getChild(size_t index) {
			return children_->at(index);
		}
		TreeNode<T>* getChild(size_t index) const {
			return children_->at(index);
		}
		void addChild(TreeNode<T>* child) {
			children_->push_back(child);
		}
		void removeChild(size_t index)
		{
			children_->erase((children_->begin() + index));
		}
		void breadthFirstTraverse(void (*datafunction)(const T)) const {
			std::deque<TreeNode<T>*> *queue = new std::deque<TreeNode<T>*>();

			//queue->push_back(this);
			for (int pos = 0; pos < children_->size(); pos++) {
				queue->push_back(children_->at(pos));
			}
			
			while(!queue->empty()) {
				TreeNode<T> *curr = queue->front();
				queue->pop_front();
				datafunction(curr->element_);
				for(int pos = 0; pos<(curr->children_)->size(); pos++) {
					queue->push_back((curr->children_)->at(pos));
				}
			}
		}
		void preOrderTraverse(void (*datafunction)(const T)) const {
			datafunction(element_);

			for(int pos = 0; pos<children_->size(); pos++) 
				(children_->at(pos))->preOrderTraverse(datafunction);
		}
		void postOrderTraverse(void (*datafunction)(const T)) const {
			for(int pos = 0; pos<children_->size(); pos++) 
				(children_->at(pos))->preOrderTraverse(datafunction);
			
			datafunction(element_);
		}
	};
}}  // namespace ufl_cap4053::fundamentals
